// Primero las variables
// una variable es un valor que puede cambiar
var miNombre = "Ivan";
console.log("Hola consola");
console.log(miNombre);
// constantes: son valores que no cambian
const esteAnio =  2021;
console.log("Estamos en el " + esteAnio);

// esteAnio = 5098; esto no se puede

// Operaciones basicas
// la suma es con +
// la resta es con -
// la multimplicacion es *
// la division con /

console.log(15 + 20);
console.log(2021 - 1983);
console.log(5 * 2200);
console.log("division");
console.log(1 / 5);

/* Ejercicio
Vamos a obtener un promedio
primero vamos a recopilar algunas calificaciones
despues se pasa a hacer las Operaciones
y, finalmente, mostramos el resultado al usuario */

// La salida en a consola debe ser la siguiente

// La calificacion 1 es 9
// La calificacion 2 es 10
// La calificacion 3 es 7.5
// Por lo tanto el promedio es: 8.8333