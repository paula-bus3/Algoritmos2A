//Xxxx
//1234
var up all night = "take me home"
console.log ("midnight memories");
consolo.log(xxxx);
// nda
const esteAnio = 2021;
console.log("Estamos en el" + esteAnio) 

//esteAnio = 5098 esto no se puede

// 1234
// 1234
// 1234
// 1234
// 1234/

console.log(1234);
console.log(1234);
console.log(12*34);
console.log("1234");
console.log(1/5); 

/*Ejercicio
Vamos a obtener un promedio
primero vamos a recopilar algunas calificaciones
despues se pasa a hacer las Operaciones
y finalmente mostramos el resultado al usuario*/

//La salida en consola debe ser la siguente

//La calificacion 1 es 9
//La calificacion 2 es 10
//La calificaion 3 es 7.5
//Por lo tanto el promedio es 8.8333

// recopilar las calificaciones
var calil= 10, cali2 = 7, cali3 = 8.25;
// operciones
var suma = calil + cali2 + cali3;
const nCalis = 3;
var promedio = suma / nCalis;

// mostrar resultados 
console.log("la calificacion es" +cali1);
console.log("la calificaion es " + cali2)
console.log("la calificacion es " + cali3);
console.log("por lo tanto el promedio es " + promedio);

//fin

/*

/*